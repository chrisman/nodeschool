# learnyoumongo

![](learnyoumongo.png)
